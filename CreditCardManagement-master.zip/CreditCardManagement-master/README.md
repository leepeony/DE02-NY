# CreditCardManagement

The objective of this case study is to create an automated system to store, process, manipulate, and query data.

## MySQL Overview

Load the existing data into the database in MySQL.

## Java Overview
This module acts as a tool for the user to query the database.

**Queries that can be ran are:**

**1.** Get Customer Details 

**2.** Modify Customer Details 

**3.** Get Number and Total Transactions by Type 

**4.** Generate Customer Bill 

**5.** Display Transaction between Dates 

**6.** Get Transactions by ZipCode 

**7.** Get Number and Total Transactions by State 


Java module files can be accessed in the src folder.

## Hadoop Overview

HDFS holds all the files in /user/maria_dev/.

The purpose of Sqoop jobs is to migrate the RDBMS data into Hadoop.

Hive files create the tables for populating data.

Oozie automates and schedules the workflow process.

## Visualization Overview

These are visualizations from Hive queries:

- Data_Visual_Hive__trans_type_by_Quarter.jpg 
- Data_Visual_Hive_top_20_zipcodes.jpg
