package exception;

public class errorException extends Exception {

    public errorException(String message) {
        super(message);
    }
}