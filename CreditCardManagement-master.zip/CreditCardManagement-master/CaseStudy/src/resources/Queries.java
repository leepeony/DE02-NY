package resources;


public class Queries {
    public final static String getCustomerBySSN = "SELECT * "
            + "FROM CDW_SAPP_CUSTOMER "
            + "WHERE SSN = ?";;

    public final static String changeCustomerDetails = "UPDATE CDW_SAPP_CUSTOMER " +
            "SET FIRST_NAME=? , MIDDLE_NAME=?, LAST_NAME =?, CREDIT_CARD_NO=? ," +
            "APT_NO= ? , STREET_NAME= ? , CUST_CITY= ? , CUST_STATE= ? , CUST_COUNTRY=? , CUST_ZIP=? , " +
            "CUST_PHONE= ? , CUST_EMAIL = ? " +
            "WHERE SSN = ?;";

    public final static String changeCustomerDetailsPrefix = "UPDATE CDW_SAPP_CUSTOMER " +
            "SET ";

    public final static String changeCustomerDetailsSuffix = "=? where SSN = ?;";

    public final static String getMonthlyBill = "SELECT SUM(TRANSACTION_VALUE) as BILL "
            + "FROM CDW_SAPP_CREDITCARD "
            + "WHERE CREDIT_CARD_NO = ? AND "
            + "MONTH = ? AND "
            + "YEAR = ? ;";

    public final static String getCustomerTrnsxBetweenTwoDates = "SELECT * "
            + "FROM CDW_SAPP_CREDITCARD "
            + "WHERE CUST_SSN =? AND "
            + "YEAR BETWEEN ? AND ? AND "
            + "MONTH BETWEEN ? AND ? AND "
            + "DAY BETWEEN ? AND ? "
            + "ORDER BY YEAR,MONTH,DAY;";

    public final static String getCustomersTrnsxByZip = "SELECT * "
            + "FROM CDW_SAPP_CREDITCARD AS card JOIN CDW_SAPP_CUSTOMER AS cust ON " +
            " card.CUST_SSN = cust.SSN " +
            "where CUST_ZIP = ? AND " +
            "MONTH = ? AND YEAR = ? " +
            "ORDER BY DAY DESC;";

    public final static String getNumberOfTrnsxAndTotalTrnsxAmountByType = "SELECT COUNT(*) as Number, SUM(TRANSACTION_VALUE) as Total "
            + "FROM CDW_SAPP_CREDITCARD "
            + "WHERE TRANSACTION_TYPE =? "
            + "GROUP BY TRANSACTION_TYPE";

    public final static String getNumberOfTrnsxAndTotalTrnsxAmountByState = "SELECT count(*) as Number, sum(TRANSACTION_VALUE) AS Total " +
            "FROM CDW_SAPP_CREDITCARD as card JOIN CDW_SAPP_BRANCH as branch ON " +
            "card.BRANCH_CODE= branch.BRANCH_CODE " +
            "WHERE branch.BRANCH_STATE = ? " +
            "GROUP BY card.BRANCH_CODE";

}