package dao;

import java.sql.SQLException;
import java.util.*;

import model.Transaction;
import resources.Queries;

public class TransactionDAO extends AbstractDAO {

    public ArrayList<Transaction> getCustomersTrnsxByZip(int zip, int month, int year) {
        ArrayList<Transaction> array = new ArrayList<>();
        Transaction transaction = null;
        establishConnection();
        String query = Queries.getCustomersTrnsxByZip;
        try {
            state = conn.prepareStatement(query);
            state.setInt(1, zip);
            state.setInt(2, month);
            state.setInt(3, year);

            result = state.executeQuery();
            while (result.next()) {
                // Initialize new Customer object, w/ parameters
                transaction = new Transaction(
                        result.getInt("TRANSACTION_ID"),
                        result.getInt("MONTH"),
                        result.getInt("DAY"),
                        result.getInt("YEAR")
                );
                array.add(transaction);
            }

            return array;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public HashMap<String, String> getNumberOfTrnsxAndTotalTrnsxAmountByType(String type) {
        HashMap<String, String> result2 = new HashMap<>();
        establishConnection();
        String query = Queries.getNumberOfTrnsxAndTotalTrnsxAmountByType;
        try {
            state = conn.prepareStatement(query);
            state.setString(1, type);

            result = state.executeQuery();
            if(result.next()) {
                result2.put("Number of Transactions", result.getInt("NUMBER")+"");
                result2.put("Total Transactions", result.getDouble("TOTAL")+"");
            }
            return result2;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public HashMap<String, String> getNumberOfTrnsxAndTotalTrnsxAmountByState(String state2) {
        HashMap<String, String> result2 = new HashMap<>();
        establishConnection();
        String query = Queries.getNumberOfTrnsxAndTotalTrnsxAmountByState;
        try {
            state = conn.prepareStatement(query);
            state.setString(1, state2);

            result = state.executeQuery();
            if(result.next()) {
                result2.put("Number of Transactions", result.getInt("NUMBER")+"");
                result2.put("Total Transactions", result.getDouble("TOTAL")+"");
            }
            return result2;
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}