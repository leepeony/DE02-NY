package dao;
import java.sql.SQLException;
import java.util.*;
import model.Customer;
import resources.Queries;
import model.Transaction;

public class CustomerDAO extends AbstractDAO {
    String[] cParameters = {
            "FIRST_NAME",
            "MIDDLE_NAME",
            "LAST_NAME",
            "SSN",
            "CREDIT_CARD_NO",
            "APT_NO",
            "STREET_NAME",
            "CUST_CITY",
            "CUST_STATE",
            "CUST_COUNTRY",
            "CUST_ZIP",
            "CUST_PHONE",
            "CUST_EMAIL"
    };

    public Customer getCustomerBySSN(int ssn) {
        Customer customer = null;
        establishConnection();
        String query = Queries.getCustomerBySSN;
        try {
            state = conn.prepareStatement(query);
            state.setInt(1, ssn);

            result = state.executeQuery();
            if(result.next()) {
                // Initialize new Customer object, w/ parameters
                customer = new Customer(
                        result.getString(cParameters[0]),
                        result.getString(cParameters[1]),
                        result.getString(cParameters[2]),
                        result.getInt(cParameters[3]),
                        result.getString(cParameters[4]),
                        result.getString(cParameters[5]),
                        result.getString(cParameters[6]),
                        result.getString(cParameters[7]),
                        result.getString(cParameters[8]),
                        result.getString(cParameters[9]),
                        result.getString(cParameters[10]),
                        result.getInt(cParameters[11]),
                        result.getString(cParameters[12])
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customer;
    }

    public void changeCustDetails(String field, String value,long id){
        try{
            establishConnection();
            state = conn.prepareStatement(Queries.changeCustomerDetailsPrefix+field+Queries.changeCustomerDetailsSuffix);

            if(field.equals("CUST_PHONE")){
                state.setLong(1,Long.parseLong(value));
            }else{
                state.setString(1,value);
            }
            state.setLong(2,id);
            state.executeUpdate();
            System.out.println("Entry has been Updated");

        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    public void generateBill(String cardNo, int month, int year){
        try{
            establishConnection();
            state= conn.prepareStatement(Queries.getMonthlyBill);
            state.setString(1,cardNo);
            state.setInt(2,month);
            state.setInt(3,year);
            result= state.executeQuery();
            while(result.next()){
                System.out.println("Monthly Bill: "+ result.getDouble("Bill"));
            }
            closeConnection();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    public void displayTransxBetweenDates(int id,int startYear,int endYear,int startMonth,
                                         int endMonth,int startDay,int endDay){

        try{
            establishConnection();
            state = conn.prepareStatement(Queries.getCustomerTrnsxBetweenTwoDates);
            state.setInt(1,id);
            state.setInt(2,startYear);
            state.setInt(3,endYear);
            state.setInt(4,startMonth);
            state.setInt(5,endMonth);
            state.setInt(6,startDay);
            state.setInt(7,endDay);
            result=state.executeQuery();
            List<Transaction> transactionList = new ArrayList<>();
            while(result.next()){
                int transaction_id = result.getInt("TRANSACTION_ID");
                int day = result.getInt("DAY");
                int month = result.getInt("MONTH");
                int year = result.getInt("YEAR");
                String creditCardNo = result.getString("CREDIT_CARD_NO");
                int custSSN = result.getInt("CUST_SSN");
                int branchCode = result.getInt("BRANCH_CODE");
                String transType = result.getString("TRANSACTION_TYPE");
                double tranVal = result.getDouble("TRANSACTION_VALUE");
                transactionList.add(new Transaction(transaction_id, day,month,
                        year,creditCardNo,custSSN,
                        branchCode,transType,tranVal));
            }
            for(Transaction t: transactionList){
                System.out.println(t);
            }
            closeConnection();

        }catch (SQLException e){
            e.printStackTrace();
        }

    }
}