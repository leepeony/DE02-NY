package model;

public class Customer {
    private String creditCardNo, state, streetName, country, city,
            fName, mName, lName, email, zip, aptNo;
    private int phone, ssn;


    // Constructors - Default
    public Customer(){}

    // Constructors - Parameterized
    public Customer(String fName, String mName, String lName, int ssn,
                    String creditCardNo, String aptNo, String streetName,
                    String city, String state, String country, String zip,
                    int phone, String email) {
        this.creditCardNo = creditCardNo;
        this.state = state;
        this.streetName = streetName;
        this.country = country;
        this.city = city;
        this.fName = fName;
        this.mName = mName;
        this.lName = lName;
        this.email = email;
        this.zip = zip;
        this.aptNo = aptNo;
        this.phone = phone;
        this.ssn = ssn;
    }



    public String getCreditCardNo() {
        return creditCardNo;
    }
    public void setCreditCardNo(String creditCardNo) {
        this.creditCardNo = creditCardNo;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getStreetName() {
        return streetName;
    }
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getfName() {
        return fName;
    }
    public void setfName(String fName) {
        this.fName = fName;
    }
    public String getmName() {
        return mName;
    }
    public void setmName(String mName) {
        this.mName = mName;
    }
    public String getlName() {
        return lName;
    }
    public void setlName(String lName) {
        this.lName = lName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getZip() {
        return zip;
    }
    public void setZip(String zip) {
        this.zip = zip;
    }
    public String getAptNo() {
        return aptNo;
    }
    public void setAptNo(String aptNo) {
        this.aptNo = aptNo;
    }
    public int getPhone() {
        return phone;
    }
    public void setPhone(int phone) {
        this.phone = phone;
    }
    public int getSsn() {
        return ssn;
    }
    public void setSsn(int ssn) {
        this.ssn = ssn;
    }

    public String toString(){
        String out = "Name:\t\t" + fName + " " + mName + " " + lName + "\n" +
                "SSN:\t\t" + ssn + "\n" +
                "Address:\t" + country + " - " + streetName + " #" + aptNo + " " + city + ", " + state + " " + zip + "\n" +
                "Contact:\tPhone - " + phone + " | Email - " + email + "\n" +
                "Credit Card:\t" + creditCardNo;

        return out;
    }
}