package main;

import dao.CustomerDAO;
import exception.errorException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;


class CustomerMain {
    private static Scanner scanner = new Scanner(System.in);
    private static CustomerDAO customerDAO = new CustomerDAO();

    static void getCustomerBySSN() throws errorException {
        System.out.println("Please enter customer SSN:");
        int input = scanner.nextInt();
        if(!isValidId(String.valueOf(input)))
            throw new errorException("Invalid input.");
        System.out.println(customerDAO.getCustomerBySSN(input));

    }


    static void changeCustDetails() {
        String firstName;
        String middleName;
        String lastName;
        long accountID;
        String creditCardNo;
        String streetName;
        String aptNo;
        String city;
        String state;
        String country;
        String zip;
        String email;
        long phone;

        System.out.println("Please enter ID");
        accountID = scanner.nextLong();
        boolean exited = false;

        String statement = "-------------\n" + " 1: Change FirstName " + "\n" +
                " 2: Change MiddleName  " + "\n" +
                " 3: Change LastName  " + "\n" +
                " 4: Change StreetName  " + "\n" +
                " 5: Change Apartment Number " + "\n" +
                " 6: Change City " + "\n" +
                " 7: Change State " + "\n" +
                " 8: Change Country " + "\n" +
                " 9: Change Zip " + "\n" +
                " 10: Change Email " + "\n" +
                " 11: Change Phone " + "\n" +
                " 12: EXIT" + "\n" +
                "-------------\n";
        while (!exited) {
            System.out.println(statement);
            int input = scanner.nextInt();
            switch (input) {
                case 1:
                    System.out.println("Please enter first name:");
                    firstName = scanner.next();
                    customerDAO.changeCustDetails("FIRST_NAME", firstName, accountID);
                    break;
                case 2:
                    System.out.println("Please enter middle name:");
                    middleName = scanner.next();
                    customerDAO.changeCustDetails("MIDDLE_NAME", middleName, accountID);
                    break;
                case 3:
                    System.out.println("Please enter last name:");
                    lastName = scanner.next();
                    customerDAO.changeCustDetails("LAST_NAME", lastName, accountID);
                    break;
                case 4:
                    System.out.println("Please enter street name:");
                    streetName = scanner.nextLine();
                    customerDAO.changeCustDetails("STREET_NAME", streetName, accountID);
                    break;
                case 5:
                    System.out.println("Please enter apartment number:");
                    aptNo = scanner.next();
                    customerDAO.changeCustDetails("APT_NO", aptNo, accountID);
                    break;
                case 6:
                    System.out.println("Please enter city:");
                    city = scanner.next();
                    customerDAO.changeCustDetails("CUST_CITY", city, accountID);
                    break;
                case 7:
                    System.out.println("Please enter state:");
                    state = scanner.next();
                    customerDAO.changeCustDetails("CUST_STATE", state, accountID);
                    break;
                case 8:
                    System.out.println("Please enter country:");
                    country = scanner.nextLine();
                    customerDAO.changeCustDetails("CUST_COUNTRY", country, accountID);
                    break;
                case 9:
                    System.out.println("Please enter zip code:");
                    zip = scanner.next();
                    customerDAO.changeCustDetails("CUST_ZIP", zip, accountID);
                    break;
                case 10:
                    System.out.println("Please enter email:");
                    email = scanner.next();
                    customerDAO.changeCustDetails("CUST_EMAIL", email, accountID);
                    break;
                case 11:
                    System.out.println("Please enter phone:");
                    phone = scanner.nextLong();
                    customerDAO.changeCustDetails("CUST_PHONE", String.valueOf(phone), accountID);
                    break;
                case 12:
                    exited = true;
                    break;

            }
        }
    }

        static void generateBill(){
            System.out.println("Please enter card number:");
            String cardNum = scanner.next();
            System.out.println("Please enter month:");
            int month = scanner.nextInt();
            System.out.println("Please enter year:");
            int year = scanner.nextInt();
            customerDAO.generateBill(cardNum, month, year);

        }

        static void getTransxBetweenDates(){
            scanner = new Scanner(System.in);
            System.out.println("Please enter customer SSN:");
            int id = scanner.nextInt();
            System.out.println("Please enter start year:");
            int startYear = scanner.nextInt();
            System.out.println("Please enter end year:");
            int endYear = scanner.nextInt();
            System.out.println("Please enter start month:");
            int startMonth = scanner.nextInt();
            System.out.println("Please enter end month:");
            int endMonth = scanner.nextInt();
            System.out.println("Please enter start day:");
            int startDay = scanner.nextInt();
            System.out.println("Please enter end day:");
            int endDay = scanner.nextInt();
            customerDAO.displayTransxBetweenDates(id, startYear, endYear, startMonth, endMonth, startDay, endDay);
        }
        static boolean isValidCard(String card){
            Pattern p = Pattern.compile("[A-Z 0-9]{16}");
            Matcher m = p.matcher(card);
            return m.matches();

        }
        static boolean isValidId(String id){
            Pattern p = Pattern.compile("[0-9]{9}");
            Matcher m = p.matcher(id);
            return m.matches();

        }
        static boolean isValidDay(String day){
            Pattern p = Pattern.compile("[\\d]{2}");
            Matcher m = p.matcher(day);
            return m.matches();

        }
        private static boolean isValidMonth(int month){
            return month<0 || month>12;
        }

    }
