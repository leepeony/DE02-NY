
package main;

import dao.TransactionDAO;
import exception.errorException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TransactionMain {
    private static Scanner scanner = new Scanner(System.in);
    private static TransactionDAO transactionDAO = new TransactionDAO();
    static void getTransbyZipcode() throws errorException {
        System.out.println("Please enter Zip Code: ");
        int zip = scanner.nextInt();
        System.out.println("Please enter Month: ");
        int month = scanner.nextInt();
        System.out.println("Please Enter Year: ");
        int year = scanner.nextInt();
        if(!isValidZip(zip)||!isValidMonth(month)||!isValidYear(year))
            throw new errorException("Invalid Input");
        System.out.println(transactionDAO.getCustomersTrnsxByZip(zip,month,year));
    }

    static void getNumAndTotalByType(){
        System.out.println("Please enter type: ");
        String type = scanner.next();
        System.out.println(transactionDAO.getNumberOfTrnsxAndTotalTrnsxAmountByType(type));
    }
    static void getNumAndTotalByState() throws errorException {
        System.out.println("Please enter state: ");
        String state = scanner.next();
        if(!isValidState(state))
            throw new errorException("Invalid Entry");
        System.out.println(transactionDAO.getNumberOfTrnsxAndTotalTrnsxAmountByState(state));
    }
    private static boolean isValidState(String state){
        Pattern p = Pattern.compile("[A-Z]{2}");
        Matcher m = p.matcher(state);
        return m.matches();

    }
    private static boolean isValidMonth(int month){
        return month<0 || month>12;
    }
    private static boolean isValidZip(int zip){
        Pattern p = Pattern.compile("[0-9]{5}");
        Matcher m = p.matcher(String.valueOf(zip));
        return m.matches();
    }
    private static boolean isValidYear(int year) {
        Pattern p = Pattern.compile("[0-9]{4}");
        Matcher m = p.matcher(String.valueOf(year));
        return m.matches();
    }
}