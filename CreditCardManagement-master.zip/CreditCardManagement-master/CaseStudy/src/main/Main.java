package main;

import java.util.*;
import exception.errorException;

public class Main {

    public static void main(String[] args) throws errorException {
        String greeting ="============\n"+" 1: Return Customer Details "+"\n"+
                " 2: Change Customer Details "+"\n" +
                " 3: Return Customer Bill "+"\n"+
                " 4: Return Transaction between Dates "+"\n"+
                " 5: Return Transactions by Zip Code "+"\n"+
                " 6: Return Number and Total Transactions by Type "+"\n"+
                " 7: Return Number and Total Transactions by State "+"\n"+
                " 8: EXIT"+"\n"+
                "============\n";

        Scanner scan = new Scanner(System.in);
        boolean exit = false;
        try{
            while(!exit){
                System.out.println(greeting);
                System.out.println("Please Enter Number: ");
                int input =scan.nextInt();
                if(input<1|| input>8)throw new InputMismatchException("Invalid Input.");
                switch (input) {
                    case 1:
                        CustomerMain.getCustomerBySSN();
                        break;
                    case 2:
                        CustomerMain.changeCustDetails();
                        break;
                    case 3:
                        CustomerMain.generateBill();
                        break;
                    case 4:
                        CustomerMain.getTransxBetweenDates();
                       break;
                    case 5:
                        TransactionMain.getTransbyZipcode();
                        break;
                    case 6:
                        TransactionMain.getNumAndTotalByType();
                        break;
                    case 7:
                        TransactionMain.getNumAndTotalByState();
                        break;
                    case 8:
                        System.out.println("Exiting program.");
                        exit=true;
                        break;

                }
            }
        }catch(InputMismatchException e){
            e.printStackTrace();
        }
        System.out.println("Good Bye!");
    }
}