SELECT 
    TRANSACTION_ID,
    credit_card_no CUST_CC_NO,
    CONCAT(year, month1, day1) TIMEID,
    cust_ssn,
    branch_code,
    transaction_type,
    TRANSACTION_VALUE
FROM
    (SELECT 
            CASE
                WHEN month < 10 THEN CONCAT(0, month)
                ELSE month
            END month1,
            CASE
                WHEN day < 10 THEN CONCAT(0, day)
                ELSE day
            END day1,
            a.*
    FROM
        CDW_SAPP.CDW_SAPP_CREDITCARD a) a;
