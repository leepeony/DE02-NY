SELECT 
    CONCAT(year, month, day) TIMEID,
    day 'DAY',
    month 'MONTH',
    CASE
        WHEN month < 4 THEN '01'
        WHEN month > 3 AND month < 7 THEN '02'
        WHEN month > 6 AND month < 10 THEN '03'
        WHEN month > 9 THEN '04'
        ELSE NULL
    END 'QUARTER',
    year 'YEAR'
FROM
    (SELECT 
        year,
            CASE
                WHEN month < 10 THEN CONCAT(0, month)
                ELSE month
            END month,
            CASE
                WHEN day < 10 THEN CONCAT(0, day)
                ELSE day
            END day
    FROM
        CDW_SAPP.CDW_SAPP_CREDITCARD) a;
