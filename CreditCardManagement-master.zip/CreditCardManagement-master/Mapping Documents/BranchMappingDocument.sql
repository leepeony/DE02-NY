SELECT 
    branch_code BRANCH_CODE,
    branch_name BRANCH_NAME,
    branch_street BRANCH_STREET,
    branch_city BRANCH_CITY,
    branch_state BRANCH_STATE,
    branch_zip BRANCH_ZIP,
    CONCAT(SUBSTRING(branch_phone, 1, 3),
            '-',
            SUBSTRING(branch_phone, 4, 3),
            '-',
            SUBSTRING(branch_phone, 7, 4)) BRANCH_PHONE,
    last_updated LAST_UPDATED
FROM
    CDW_SAPP_BRANCH;
